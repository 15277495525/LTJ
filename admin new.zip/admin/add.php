<html>
<body>
    <form action="add.handle.php" method="POST">
        name:         <input type="text" name="name"><br>
        connect:<input type="text" name="connect"><br>
        price:        <input type="text" name="price"><br>
        <input type="submit"value="�ύ">
    </form>
</body>
</html>
