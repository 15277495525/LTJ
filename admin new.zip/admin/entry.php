<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">

</head>
<body>
<form method="post">

账号&nbsp;<input type="text">
密码&nbsp;<input type="password">
<input type="submit"value="登录">

</form>

</body>
</html>


