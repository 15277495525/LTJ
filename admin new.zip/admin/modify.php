<?php
    require_once 'connect.php';
   /*��$name="lisi";ɾ���ˡ�
           ��$sql="UPDATE library SET connect='connect is modified' WHERE name='$name'";
           �ĳ���$sql="UPDATE library SET connect='connect is modified' WHERE name='zhangsan'";*/
    $sql="UPDATE library SET connect='connect is modified' WHERE name='zhangsan'";
    if(mysqli_query($con, $sql))
    {
        echo "modify success!";
    }
